import streamlit as st
import pandas as pd
import joblib

# —————————————————————————————
# 1. Load pipeline ter‐fitted & data
# —————————————————————————————
# Gunakan try-except untuk menangani error loading
try:
    pipeline = joblib.load("pipeline_best.pkl")  # Preprocessing + Model
except ModuleNotFoundError:
    st.error("Gagal memuat pipeline. Pastikan file pipeline_best.pkl dan versi NumPy sudah sesuai.")
    st.stop()

# Data asli untuk opsi input
df = pd.read_csv("data.csv", delimiter=";")

# —————————————————————————————
# 2. UI Streamlit: Desain yang ditingkatkan
# —————————————————————————————
st.set_page_config(
    page_title="Deteksi Dropout Siswa",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Header dengan deskripsi
st.markdown(
    """
    # 📘 Sistem Deteksi Risiko Dropout
    Aplikasi ini memprediksi risiko **dropout** siswa Jaya Jaya Institut.
    Masukkan data siswa di sidebar untuk melihat hasil prediksi.
    """
)

# Sidebar untuk input pengguna
with st.sidebar:
    st.header("Masukkan Data Siswa")

    # Mapping Gender
    gender_map = {0: "Perempuan", 1: "Laki-laki"}
    gender_label = st.selectbox("Jenis Kelamin", list(gender_map.values()))
    gender_code = [k for k, v in gender_map.items() if v == gender_label][0]

    # Slider Usia
    age = st.slider(
        "Usia Saat Pendaftaran",
        min_value=int(df["Age_at_enrollment"].min()),
        max_value=int(df["Age_at_enrollment"].max()),
        value=int(df["Age_at_enrollment"].median())
    )

    # Pilihan Course dinamis
    courses = sorted(df["Course"].unique().tolist())
    course_map = {c: f"Course {c}" for c in courses}
    course_label = st.selectbox("Course", list(course_map.values()))
    course_code = [k for k, v in course_map.items() if v == course_label][0]

    # Fitur lanjutan
    with st.expander("Fitur Lanjutan (Opsional)"):
        # Previous Qualification
        prevs = sorted(df["Previous_qualification"].unique().tolist())
        prev_map = {p: f"Kode {p}" for p in prevs}
        prev_label = st.selectbox("Kualifikasi Sebelumnya", list(prev_map.values()))
        prev_code = [k for k, v in prev_map.items() if v == prev_label][0]

        # Admission Grade
        admission_grade = st.slider(
            "Admission Grade",
            float(df["Admission_grade"].min()),
            float(df["Admission_grade"].max()),
            float(df["Admission_grade"].median())
        )

    st.markdown("---")
    pred_button = st.button("Prediksi Dropout")

# —————————————————————————————
# 3. Logic Prediksi & Hasil
# —————————————————————————————
if pred_button:
    # Kumpulkan input ke DataFrame
    input_dict = {
        "Gender": [gender_code],
        "Age_at_enrollment": [age],
        "Course": [course_code],
        "Previous_qualification": [prev_code],
        "Admission_grade": [admission_grade]
    }
    input_df = pd.DataFrame(input_dict)

    # Pastikan kolom lengkap sesuai fitur pipeline
    feature_names = pipeline.named_steps['pre'].feature_names_in_
    num_cols = pipeline.named_steps['pre'].transformers_[0][2]
    cat_cols = pipeline.named_steps['pre'].transformers_[1][2]
    for col in feature_names:
        if col not in input_df.columns:
            if col in num_cols:
                input_df[col] = df[col].median()
            else:
                input_df[col] = df[col].mode()[0]
    input_df = input_df[feature_names]

    # Prediksi
    y_pred = pipeline.predict(input_df)[0]
    y_proba = pipeline.predict_proba(input_df)[0, 1]

    # Tampilkan hasil
    col1, col2 = st.columns([1, 2])
    with col1:
        st.metric("Probabilitas Dropout", f"{y_proba*100:.1f}%")
    with col2:
        if y_pred == 1:
            st.error("⚠️ Siswa berisiko dropout!")
        else:
            st.success("✅ Siswa tidak berisiko tinggi.")

    # Rekomendasi tindak lanjut
    if y_proba > 0.7:
        st.info("Intervensi segera diperlukan.")
    elif y_proba > 0.4:
        st.info("Monitoring lanjutan direkomendasikan.")
    else:
        st.info("Risiko rendah.")

# —————————————————————————————
# 4. Footer
# —————————————————————————————
st.markdown("---")
st.markdown("Dicoding | Project by Julio Aldrin Purba")
